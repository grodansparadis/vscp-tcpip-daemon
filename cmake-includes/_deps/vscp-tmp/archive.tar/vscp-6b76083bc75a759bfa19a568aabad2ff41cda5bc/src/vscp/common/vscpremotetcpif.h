///////////////////////////////////////////////////////////////////////////////
// vscpremotetcpif.h:
//
// This file is part of the VSCP (https://www.vscp.org)
//
// The MIT License (MIT)
//
// Copyright (C) 2000-2026 Ake Hedman and contributors, the VSCP project
// <info@vscp.org>
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

/*!
    \file    vscptcpif.h
    \brief   The VscpTcpIf class encapuslate sthe VSCP tcp/ip interface.
    \details The VscpTcpIf class holds functionality to talk toi the tcp/ip
    of the VSCP daemon and on client that implement the interface. All api's
    of the interface are supported by the class.
 */

#if !defined(VSCPREMOTETCPIF_H__INCLUDED_)
#define VSCPREMOTETCPIF_H__INCLUDED_

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

#ifndef WIN32
#include <arpa/inet.h>
#include <netdb.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <pthread.h>
#include <semaphore.h>
#include <sys/poll.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/utsname.h>
#include <sys/wait.h>
#include <unistd.h>
#else
#include <winsock2.h>
#include <windows.h>
#include <pthread.h>
#include <semaphore.h>
#endif

#include <inttypes.h>
#include <stdint.h>
#include <stdlib.h>
#include <memory>

#include <canal.h>
#include <guid.h>
#include <vscp.h>
#include <vscpdatetime.h>
#include <vscphelper.h>

//---------------------------------------------------------------------------

/*!
    @def DEFAULT_RESPONSE_TIMEOUT
    Default response timeout for communication with the
    tcp/ip interface of the daemon in milliseconds.

    This is the overall time to wait for a +OK respose.
 */
#define TCPIP_DEFAULT_RESPONSE_TIMEOUT 2000 // ms

/*!
 *   Default connect timeout
 */
#define TCPIP_DEFAULT_CONNECT_TIMEOUT_SECONDS 15 // Seconds

/*!
    @def DEFAULT_INNER_RESPONSE_TIMEOUT
    Default timeout for inner data check. A Read call will
    always wait this long for data.
*/
#define TCPIP_DEFAULT_INNER_RESPONSE_TIMEOUT 10

// Default values for read/write register functions
// used in device config and scan.
#define TCPIP_REGISTER_READ_RESEND_TIMEOUT 1000
#define TCPIP_REGISTER_READ_ERROR_TIMEOUT  5000
#define TCPIP_REGISTER_READ_MAX_TRIES      3

/*!
    @def TCPIP_DLL_VERSION
    Pseudo version string
 */
#define TCPIP_DLL_VERSION 0x000f0002 // 15.0.2
/*!
    @def TCPIP_VENDOR_STRING
    Vendor string
 */
#define TCPIP_VENDOR_STRING "the VSCP project, https://www.vscp.org"
#define DRIVER_INFO_STRING  ""

/*!
    Use this macro for unused function parameters.
 */
#define TCPIP_UNUSED(__par) (void) (__par)

// Forward declarations
class VscpRemoteTcpIf;
struct mg_connection;

/*!
    @brief Class for VSCP daemon tcp/ip interface
 */
class VscpRemoteTcpIf {
public:
  enum class tls_mode {
    auto_select = 0, // Select TLS based on endpoint prefix (stcp://)
    force_tls,       // Always use TLS
    force_plain      // Never use TLS
  };

  /// Constructor
  VscpRemoteTcpIf();

  /// Destructor
  virtual ~VscpRemoteTcpIf();

  VscpRemoteTcpIf(const VscpRemoteTcpIf &) = delete;
  VscpRemoteTcpIf &operator=(const VscpRemoteTcpIf &) = delete;

public:
  /*!
      Set connect timeout.
      @param to Timeout value in **seconds**.
   */
  void setConnectTimeout(uint16_t to = TCPIP_DEFAULT_CONNECT_TIMEOUT_SECONDS) { m_connectionTimeOut = to; };

  /*!
      Get connection timeout (in seconds)
      @return Connection timeout in **seconds**
  */
  uint16_t getConnectTimeout(void) { return m_connectionTimeOut; };

  /*!
      Set response timeout.
      @param to Timeout value in milliseconds.
   */
  void setResponseTimeout(uint32_t to = TCPIP_DEFAULT_RESPONSE_TIMEOUT)
  {
    if (to < 100)
      to = 1000; // To be backward compatible
    if (to)
      m_responseTimeOut = to;
  };

  /*!
      Get response timeout
      @return Response timeout in milliseconds
  */
  uint32_t getResponseTimeout(void) { return m_responseTimeOut; };

  /*!
      Set after command sleep time (milliseconds)
      @param to Sleep value in milliseconds.
   */
  void setAfterCommandSleep(uint16_t to)
  {
    TCPIP_UNUSED(to); // For backward compatibility
  }

  /*!
      Set inner response timeout
      @param to Timeout value in milliseconds. 0 = return immediately, -1 = use default value (2000 ms)
   */
  void setInnerResponseTimeout(uint32_t to = TCPIP_DEFAULT_INNER_RESPONSE_TIMEOUT) { m_innerResponseTimeout = to; };

  /*!
      Get inner response timeout
      @return Inner response timeout in milliseconds. 0 = return immediately, -1 = use default value (2000 ms)
  */
  uint32_t getInnerResponseTimeout(void) { return m_innerResponseTimeout; };

  /*!
      Set register read/write timings
   */
  void setRegisterOperationTiming(uint8_t retries, uint32_t resendto, uint32_t errorto)
  {
    m_registerOpMaxRetries    = retries;
    m_registerOpResendTimeout = resendto;
    m_registerOpErrorTimeout  = errorto;
  };

  /*!
      Get last response form remote node
      @return Last raw response data from remote node
   */
  std::string &getLastResponse(void) { return m_strResponse; };

  /*!
      Get last response time
      @return Relative time in milliseconds when last valid received
          data was read.
  */
  uint32_t getlastResponseTime(void) { return m_lastResponseTime; };

  /*!
      Returns TRUE if we are connected false otherwise.
   */
  bool isConnected(void);

  /*!
      checkReturnValue
      @param bClear Clear the input bugger before starting to wait for
     received data.
      @return Return false for "-OK" and true for "+OK"
   */
  bool checkReturnValue(bool bClear = false);

  /*!
      ReceiveLoop reader
      Intended for thread loop workerthread
      @param timout Timeout in milliseconds to wait for event
      @return VSCP_ERROR_SUCCESS on success, otherise errorcode
  */
  int rcvloopRead(int timeout);

  /*!
      Clear the input queue
   */
  void doClrInputQueue(void);

  /*!
      \brief Creates the input string array from a remote client response
      @return Number of rows in created string array.
  */
  size_t addInputStringArrayFromReply(bool bClear = false);

  /*!
      \brief Send a command to the remote client.
      @param cmd Commad to issue
      @return Returns VSCP_ERROR_SUCCESS if the command could be sent
     successfully.
   */
  int doCommand(const std::string &cmd);

  /*!
      \brief Send a command to the remote client.
      @param cmd Commad to issue
      @return Returns VSCP_ERROR_SUCCESS if the command could be sent
     successfully.
   */
  int doCommand(const char *cmd);

  /*!
      Open communication interface.
      @param strInterface should contain "ip-addr:port;username;password" if
     used. All including port are optional and defaults to no
     username/password, server as "localhost" and "9598" as default port.
     Interface can be given as
        tcp://host:port;username;password
        or
        host:port;username;password
      @param flags are not used at the moment.
      @return CANAL_ERROR_SUCCESS if channel is open or CANAL error code  if
     error or the channel is already opened or other error occur.
   */
  int doCmdOpen(const std::string &strInterface = std::string(""), uint32_t flags = 0L);

  /*!
      Open communication interface.
      @param strHostname Host to connect to + port (host:port).
      @param strUsername Username.
      @param strPassword Username.
      @return CANAL_ERROR_SUCCESS if channel is open or CANAL error code if
     error or the channel is already opened or other error occur.
   */
  int doCmdOpen(const std::string &strHostname, const std::string &strUsername, const std::string &strPassword);

  /*!
      Open communication interface.
      @param strHostname Host to connect to.
      @param port Port of interface to connec to
      @param strUsername Username.
      @param strPassword Username.
      @return CANAL_ERROR_SUCCESS if channel is open or CANAL error code if
     error or the channel is already opened or other error occur.
   */
  int doCmdOpen(const std::string &strHostname,
                short port,
                const std::string &strUsername,
                const std::string &strPassword);

  /*!
      Close communication interface
      @return CANAL_ERROR_SUCCESS on success and error code if failure.
   */
  int doCmdClose(void);

  /*!
      Write NOOP message through pipe.
      @return CANAL_ERROR_SUCCESS on success and error code if failure.
   */
  int doCmdNOOP(void);

  /*!
      Clear input queue
      @return CANAL_ERROR_SUCCESS on success and error code if failure.
   */
  int doCmdClear(void);

  /*!
      Get the Canal protocol level
      @return VSCP Level
   */
  unsigned long doCmdGetLevel(void) { return VSCP_LEVEL2; }

  /*!
      Send a VSCP Level II event through interface.
      If a GUID sent with all items set to zero the GUID of the
      interface ("-") will be used.
      @param pEvent VSCP Level II event to send.
      @return CANAL_ERROR_SUCCESS on success and error code if failure.
   */
  int doCmdSend(const vscpEvent *pEvent);

  /*!
      Send a VSCP ex event through interface.
      @param pEvent VSCP Level II ex event to send.
      @return CANAL_ERROR_SUCCESS on success and error code if failure.
   */
  int doCmdSendEx(const vscpEventEx *pEvent);

  /*!
      Send a Level I event through interface.
      @param pMsg VSCP Level I event (==canalMsg).
      @return CANAL_ERROR_SUCCESS on success and error code if failure.
   */
  int doCmdSendLevel1(const canalMsg *pMsg);

  /*!
      Receive a VSCP event through the interface.
      @return CANAL_ERROR_SUCCESS on success and error code if failure.
   */
  int doCmdReceive(vscpEvent *pEvent);

  /*!
      Receive an VSCP ex event through the interface.
      @return true if success false if not.
   */
  int doCmdReceiveEx(vscpEventEx *pEvent);

  /*!
      Receive an VSCP Level I event through the interface.
      For the extended and the RTR bit to be handled the
      CAN message bit in the head byte must be set.
      Low eight bits of the CAN id is fetched from GUID[15]
      that is LSB of GUID.
      @param Pointer to CANAL message
      @return CANAL_ERROR_SUCCESS if success false if not.
   */
  int doCmdReceiveLevel1(canalMsg *pCanalMsg);

  /*!
      This command sets an open interface in the receive loop (RCVLOOP).
      It does nothing other then putting the interface in the loop mode and
      checking that it went there.

      Note! The only way to terminate this receive loop is to close the
     session with doCmdClose (or just close the socket).

      @return CANAL_ERROR_SUCCESS if success CANAL_ERROR_GENERIC if not.
   */
  int doCmdEnterReceiveLoop(void);

  /*!
      Quit the receive loop
   */
  int doCmdQuitReceiveLoop(void);

  /*!
      Receive an event
      The receiveloop command must have been issued for this method to work as
      it sets up the ringbuffer used for the blocking receive.
      @param pEvent Pointer to VSCP event.
      @param timeout Timout to wait for data. Default = 500 milliseconds.
      @return CANAL_ERROR_SUCCESS when event is received.
     CANAL_ERROR_FIFO_EMPTY is returned if no event was available.
     CANAL_ERROR_TIMEOUT on timeout.CANAL_ERROR_COMMUNICATION is returned if a
     socket error is detected.
  */
  int doCmdBlockingReceive(vscpEvent *pEvent, uint32_t timeout = 500);

  int doCmdBlockingReceive(vscpEventEx *pEventEx, uint32_t timeout = 500);

  /*!
    Get the number of events in the input queue of this interface
    @return the number of events available or if negative
    an error code.
   */
  int doCmdDataAvailable(void);

  /*!
    Receive CAN status through the interface.
    @return CANAL_ERROR_SUCCESS on success and error code if failure.
   */
  int doCmdStatus(canal_status_t *pStatus);

  /*!
    A VSCP variant of the above
   */
  int doCmdStatus(vscp_status_t *pStatus);

  /*!
    Receive VSCP statistics through the interface.
    @return CANAL_ERROR_SUCCESS on success and error code if failure.
   */
  int doCmdStatistics(vscp_statistics_t *pStatistics);

  /*!
      Receive CAN statistics through the interface.
      @return CANAL_ERROR_SUCCESS on success and error code if failure.
   */
  int doCmdStatistics(canal_statistics_t *pStatistics);

  /*!
      Set/Reset a filter through the interface.
      @return CANAL_ERROR_SUCCESS on success and error code if failure.
   */
  int doCmdFilter(const vscpEventFilter *pFilter);

  /*!
      Set/Reset filter through the interface.
      @param filter Filter on string form (priority,class,type,guid).
      @param mask Mask on string form (priority,class,type,guid).
      @return CANAL_ERROR_SUCCESS on success and error code if failure.
   */
  int doCmdFilter(const std::string &filter, const std::string &mask);

  /*!
      Get i/f version through the interface.
      @return CANAL_ERROR_SUCCESS on success and error code if failure.
   */
  int doCmdVersion(uint8_t *pMajorVer, uint8_t *pMinorVer, uint8_t *pSubMinorVer);

  /*!
      Get i/f version including build-version through the interface.
      @return CANAL_ERROR_SUCCESS on success and error code if failure.
   */
  int doCmdVersion(uint8_t *pMajorVer, uint8_t *pMinorVer, uint8_t *pSubMinorVer, uint16_t *pBuildVer);

  /*!
      Get interface version
   */
  unsigned long doCmdDLLVersion(void);

  /*!
      Get vendor string
   */
  const char *doCmdVendorString(void);

  /*!
      Get Driver information string.
   */
  const char *doCmdGetDriverInfo(void);

  /*!
      Get GUID for this interface.
      @return CANAL_ERROR_SUCCESS on success and error code if failure.
   */
  int doCmdGetGUID(unsigned char *pGUID);

  /*!
      Get GUID for this interface.
      @return CANAL_ERROR_SUCCESS on success and error code if failure.
   */
  int doCmdGetGUID(cguid &ifguid);

  /*!
      Set GUID for this interface.
      @param pGUID Array with uint8_t GUID's. (Note! Not a string).
      @return CANAL_ERROR_SUCCESS on success and error code if failure.
   */
  int doCmdSetGUID(const unsigned char *pGUID);

  /*!
      Set GUID for this interface.
      @param ifguid GUID to set.
      @return CANAL_ERROR_SUCCESS on success and error code if failure.
   */
  int doCmdSetGUID(cguid &ifguid);

  /*!
      Get information about a channel..
      @param pChannelInfo The stucture that will get the information
      @return CANAL_ERROR_SUCCESS on success and error code if failure.
   */
  int doCmdGetChannelInfo(vscp_channel_info_t *pChannelInfo);

  /*!
      Get Channel ID for the open channel
      @param pChannelID Channel ID for channel
      @return CANAL_ERROR_SUCCESS on success and error code if failure.
   */
  int doCmdGetChannelID(uint32_t *pChannelID);

  /*!
      Get available interfaces
      @param array A string array that will get interface list
      @return CANAL_ERROR_SUCCESS on success and error code if failure.
   */
  int doCmdInterfaceList(std::deque<std::string> &array);

  /*!
      Get server capabilities WCYD
      WCYD (What Can You Do)
      @param pwcyd Pointer to uint64_t that receive capability code
      @return VSCP_ERROR_SUCCESS if OK, else failure code
  */
  int doCmdWcyd(uint64_t *pwcyd);

  /*!
      Dummy for Baudrate setting
   */
  int doCmdSetBaudrate(uint32_t baudrate)
  {
    TCPIP_UNUSED(baudrate);
    return CANAL_ERROR_SUCCESS;
  };

  /*!
      Dummy for filter setting
   */
  int doCmdFilter(uint32_t filter)
  {
    TCPIP_UNUSED(filter);
    return CANAL_ERROR_SUCCESS;
  };

  /*!
      Dummy for mask setting
   */
  int doCmdMask(uint32_t mask)
  {
    TCPIP_UNUSED(mask);
    return CANAL_ERROR_SUCCESS;
  };

  /*!
      Shutdown the VSCP daemon
   */
  int doCmdShutDown(void);

  /*!
      Get a VSCP event from a line of data from the server
      @param pEvent Pointer to VSCP event.
      @param strLine String with server event data line
      @return true on success.
   */
  bool getEventFromLine(vscpEvent *pEvent, const std::string &strLine);

  /*!
      Get server capabilities WCYD
      WCYD (What Can You Do)
      @param pwcyd Pointer to uint64_t that receive capability code
      @return VSCP_ERROR_SUCCESS if OK, else failure code
  */
  int doCmdWcyd(uint64_t &pwcyd);

  // ------------------------------------------------------------------------
  //                           R E G I S T E R S
  // ------------------------------------------------------------------------

  /*!
      Read a level II register

      @param reg Register to read (32-bit value for true Level II)
      @param page Page to read from.
      @param pval Pointer to eight bit value that will get read value.
      @param pdestGUID GUID for remote node.
      @param ifGUID GUID for interface this events hsould be sent on. This is
              used to read registers of Level I devices.
      @param bLevel2 If true this is a true Level II read operation.
      @return CANAL_ERROR_SUCCESS on success, errocode on failure.
   */

  int readLevel2Register(uint32_t reg,
                         uint16_t page,
                         uint8_t *pval,
                         cguid &ifGUID,
                         cguid *pdestGUID = NULL,
                         bool bLevel2     = false);

  /*!
      Load level II register content into an array

      @param reg First register to read..
      @param count Number of registers to read (max 128 bytes).
      @param page Page to read from.
      @param pregisters Pointer to an array of count 8-bit registers.
      @param pinterfaceGUID GUID for interface to do read on.
      @param pdestGUID GUID for remote node.
      @param bLevel2 True for a true Level II device.
      @return CANAL_ERROR_SUCCESS on success, errocode on failure.
   */

  int readLevel2Registers(uint32_t reg,
                          uint16_t page,
                          uint8_t count,
                          uint8_t *pval,
                          cguid &ifGUID,
                          cguid *pdestGUID = NULL,
                          bool bLevel2     = false);

  /*!
      Write a level 2 register

      @param reg Register to write.
      @param pval Pointer to data to write. Return read data.
      @param interfaceGUID GUID for interface where devices sits whos register
                  should be read with byte 0 set to nickname id for the
     device.
      @param pdestGUID GUID for remote node.
      @return CANAL_ERROR_SUCCESS on success, errocode on failure.
   */
  int writeLevel2Register(uint32_t reg,
                          uint16_t page,
                          uint8_t *pval,
                          cguid &ifGUID,
                          cguid *pdestGUID = NULL,
                          bool bLevel2     = false);

  /*!
      Get MDf file from device registers

      @param pdestGUID Pointer to guid of node.
      @param strurl URL to MDF if call is successful.
      @param bLevel2 Set to true if this is a level II devive
      @return true on success, false on failure.
   */
  bool getMDFUrlFromLevel2Device(cguid &ifGUID, cguid &destGUID, std::string &strurl, bool bLevel2 = false);

  /*!
      Fetch guid for a tcp/ip interface from it's name.

      @param ifName Interface name
      @param guid Returnd GUID for interface
      @param Returns true on success.
   */
  int fetchIterfaceGUID(const std::string &ifName, cguid &guid);

  // ------------------------------------------------------------------------

public:
protected:
  /*!
      Array that gets filled with input lines
   */
  std::deque<std::string> m_inputStrArray;

  // Last read valid response in milliseconds
  // Used to detect dead (rcvloop) link.
  uint32_t m_lastResponseTime;

private:
  /// Flag for active receive loop
  bool m_bModeReceiveLoop;

  /// Server connection timeout in **seconds**
  uint16_t m_connectionTimeOut;

  /// Server response timeout in milliseconds
  uint32_t m_responseTimeOut;

  /// Error timeout for register read/write operations
  uint32_t m_registerOpErrorTimeout;

  /// Resend timeout for read/write operations
  uint32_t m_registerOpResendTimeout;

  /// Number of read/write retries
  uint8_t m_registerOpMaxRetries;

  /*!
   * The tcp inner timeout. Will always wait this amount of time for data
   * if set to -1 default value 2000 ms will be used.
   * Min value is 0 == return directly.
   */
  int m_innerResponseTimeout;

  /*!
      Version information is stored whenever the
      version command is used (always done when done on 'open').
      Initialized to the same version as this system on startup.
  */
  uint8_t m_version_year;
  uint8_t m_version_month;
  uint64_t m_version_patch;

  /*!
      Get input queue count
      @return Number of messages in the queue
   */
  size_t getInputQueueCount(void);

public:
  // ------------------------------------------------------------------------
  //                                 TLS / SSL
  // ------------------------------------------------------------------------

  /*!
      Enable TLS/SSL for the connection.
      When set, doCmdOpen negotiates TLS through Mongoose before login.
  */
  void enableTLS(bool bEnable = true)
  {
    m_tlsMode = bEnable ? tls_mode::force_tls : tls_mode::force_plain;
    m_bTLS    = bEnable;
  };

  void setTLSAutoSelect(void)
  {
    m_tlsMode = tls_mode::auto_select;
    m_bTLS    = false;
  };

  /*!
      Set TLS selection mode.
  */
  void setTLSMode(tls_mode mode)
  {
    m_tlsMode = mode;
    if (tls_mode::force_tls == m_tlsMode) {
      m_bTLS = true;
    }
    else if (tls_mode::force_plain == m_tlsMode) {
      m_bTLS = false;
    }
  };

  /*!
      Get current TLS selection mode.
  */
  tls_mode getTLSMode(void) const { return m_tlsMode; };

  /*!
      Set TLS/SSL options
      @param bVerifyPeer Verify the server certificate and hostname (default
          connection policy). False explicitly opts into insecure TLS.
      @param cafile Path to CA certificate file.
      @param capath Path to CA certificate directory.
      @param certfile Path to client certificate file.
      @param keyfile Path to client private key file.
      @param pwKeyfile Password for the private key file.
  */
  void setTLSOptions(bool bVerifyPeer,
                     const std::string &cafile    = "",
                     const std::string &capath    = "",
                     const std::string &certfile  = "",
                     const std::string &keyfile   = "",
                     const std::string &pwKeyfile = "")
  {
    m_tlsMode     = tls_mode::force_tls;
    m_bTLS        = true;
    m_bVerifyPeer = bVerifyPeer;
    m_cafile      = cafile;
    m_capath      = capath;
    m_certfile    = certfile;
    m_keyfile     = keyfile;
    m_pwKeyfile   = pwKeyfile;
  };

  /// Enable TLS/SSL
  bool m_bTLS;

  /// How TLS should be selected for connections
  tls_mode m_tlsMode;

  /// Verify peer certificate
  bool m_bVerifyPeer;

  /// CA file
  std::string m_cafile;

  /// Path to CA certificates
  std::string m_capath;

  /// Path to client certificate file
  std::string m_certfile;

  /// Path to client key file
  std::string m_keyfile;

  /// Password for key file
  std::string m_pwKeyfile;

  /*!
      The connection structure
      Not NULL if connected.
  */
  struct mg_connection *m_conn;

  /*!
   * This is the last response from a remote node.
   * It can contain multiple response lines (separated
   * with \r\n) and will end with a line containg +OK
   * or -ERR if an error response was receved.
   */
  std::string m_strResponse;

private:
  struct Transport;
  std::unique_ptr<Transport> m_transport;
  static void transportHandler(struct mg_connection *conn, int event, void *data);
  int transportRead(void *buffer, size_t length, int timeout);
  void transportClose();
};

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

//
// The following is helper code to make a threaded interface to the above
// function calls.
// The thread should be created DETACHABLE and be terminated by setting
// to true. Before starting the thread the m_pCtrlObject must be set up
// to point to an initialized ctrlObjVscpTcpIf
//

//	Receive tread states

/*!
        @def RX_TREAD_STATE_NONE
        Idle state
 */
#define RX_TREAD_STATE_NONE 0
/*!
        @def RX_TREAD_STATE_CONNECTED
        Connected state
 */
#define RX_TREAD_STATE_CONNECTED 1
/*!
        @def RX_TREAD_STATE_FAIL_DISCONNECTED
        Fail state
 */
#define RX_TREAD_STATE_FAIL_DISCONNECTED 2
/*!
        @def RX_TREAD_STATE_DISCONNECTED
        Disconnected state
 */
#define RX_TREAD_STATE_DISCONNECTED 3

/// Maximum number of events in receive queue
#define MAX_TREAD_RECEIVE_EVENTS 8192

/*!
        \class ctrlObjVscpTcpIf
        \brief Shared VSCP tcp/ip object among worker threads.
 */
class ctrlObjVscpTcpIf {
public:
  /// Constructor
  ctrlObjVscpTcpIf();

  /// Destructor
  ~ctrlObjVscpTcpIf();

  /// Username for VSCP server
  std::string m_strUsername;

  /// Password for VSCP server
  std::string m_strPassword;

  /// Host address for VSCP server
  std::string m_strHost;

  /// Port for VSCP server
  int m_port;

  /// Thread run control (set to true to terminate thread)
  bool m_bQuit;

  /// Thread error return code
  long m_error;

  /// RX Thread run state
  uint8_t m_rxState;

  /*!
      Channel id for receive channel
   */
  uint32_t m_rxChannelID;

  /*!
      Channel id for transmit channel
      If bFilterOwnTx is true events
      with this obid will not be added
      to the queue.
   */
  uint32_t m_txChannelID;

  /*!
      Filter our own tx events identified by
      obid set in m_txChannelID
   */
  bool m_bFilterOwnTx;

  /*!
      Send receive event instead of writing
      event to RX queue.
      m_pWnd must point to a valid window and
      the id for that window must be in m_wndID
      Also TX events will be activated if thread is
      started.
   */
  bool m_bUseRXTXEvents;

  /// Id for owner window (0 if not used).
  uint32_t m_wndID;

  /// Event Input queue
  std::deque<vscpEvent *> m_rxQueue;

  /// Protection for input queue
  pthread_mutex_t m_mutexRxQueue;
  sem_t m_semRxQueue;

  /// Max events in queue
  uint32_t m_maxRXqueue;

  /// Event output queue
  std::deque<vscpEvent *> m_txQueue;

  //@{
  /// Protection for output queue
  pthread_mutex_t m_mutexTxQueue;
  sem_t m_semTxQueue;
  //@}
};

/*!
        \class remotetcpipRxObj
        \brief This class implement a thread that handles
        receive events for a link to the VSCP daemon.
 */

class remotetcpipRxObj {
public:
  /// Constructor
  remotetcpipRxObj();

  /// Destructor
  virtual ~remotetcpipRxObj();

  /*!
          Pointer to control object.
   */
  ctrlObjVscpTcpIf *m_pCtrlObject;
};

/*!
        \class remotetcpipTxObj
        \brief This class implement a thread that handles
        transmit events for a link to the VSCP daemon.
 */

class remotetcpipTxObj {
public:
  /// Constructor
  remotetcpipTxObj();

  /// Destructor
  virtual ~remotetcpipTxObj();

  /*!
          Pointer to the daemon main control object.
   */
  ctrlObjVscpTcpIf *m_pCtrlObject;
};

#endif // !defined(VSCPREMOTETCPIF_H__INCLUDED_)
